# Years in Chords

Optional but recommended: Put Vibra Slap on top of Bass Drum

## Instruments

* Flutes (1, 2\)  
* Oboe (1, 2\)  
* Clarinet (1, 2\)  
* Bass Clarinet  
* Bassoon  
* Alto Saxophone (1, 2\)  
* Tenor Saxophone  
* Bass Saxophone  
* Trumpet (1, 2, 3\)  
* Horn (1, 2\)  
* Euphonium  
* Tuba  
* Percussion Section  
  * Percussion 1  
    * Snare Drum  
    * Bass Drum (with vibra slap)  
    * Suspended Cymbal  
    * Crash Cymbal  
  * Percussion 2  
    * Xylophone (I want to play this)  
    * Bells  
    * Chimes  
  * Percussion 3  
    * Tom Toms  
    * Triangle  
  * Percussion 4 (Felix recommended for this, since he’s a piano level 8\)  
    * Wood Blocks \-\> Piano

### Percussion Section

Percussion 1 \- three people (3)  
Percussion 2 \- two people (2)  
Percussion 3 \- one people (1)  
Percussion 4 \- one people (1)  
In total           \- seven people (7)

Made by Jimmy Wu